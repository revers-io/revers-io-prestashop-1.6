<?php

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\Exception\InactiveScopeException;
use Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Exception\RuntimeException;
use Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;

/**
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 */
class ReversIOContainer extends Container
{
    private $parameters;
    private $targetDirs = array();

    public function __construct()
    {
        $this->parameters = $this->getDefaultParameters();

        $this->services =
        $this->scopedServices =
        $this->scopeStacks = array();
        $this->scopes = array();
        $this->scopeChildren = array();
        $this->methodMap = array(
            'apiclient' => 'getApiclientService',
            'apiheadersbuilder' => 'getApiheadersbuilderService',
            'arrayadapter' => 'getArrayadapterService',
            'autentification' => 'getAutentificationService',
            'brandrepository' => 'getBrandrepositoryService',
            'brandservice' => 'getBrandserviceService',
            'categorymaprepository' => 'getCategorymaprepositoryService',
            'categorymapservice' => 'getCategorymapserviceService',
            'categoryrepository' => 'getCategoryrepositoryService',
            'clientfactory' => 'getClientfactoryService',
            'colourgetter' => 'getColourgetterService',
            'databaseinstall' => 'getDatabaseinstallService',
            'exportedproductsrepository' => 'getExportedproductsrepositoryService',
            'installer' => 'getInstallerService',
            'loggerservice' => 'getLoggerserviceService',
            'logservice' => 'getLogserviceService',
            'logsrepository' => 'getLogsrepositoryService',
            'modelservice' => 'getModelserviceService',
            'namegetter' => 'getNamegetterService',
            'orderimportservice' => 'getOrderimportserviceService',
            'orderrepository' => 'getOrderrepositoryService',
            'ordersadmin' => 'getOrdersadminService',
            'ordersimport' => 'getOrdersimportService',
            'orderslistingrepository' => 'getOrderslistingrepositoryService',
            'ordersretrieveservice' => 'getOrdersretrieveserviceService',
            'orderstatuses' => 'getOrderstatusesService',
            'productexportrepository' => 'getProductexportrepositoryService',
            'productforexportservice' => 'getProductforexportserviceService',
            'productimporter' => 'getProductimporterService',
            'productrepository' => 'getProductrepositoryService',
            'productsforexportrepository' => 'getProductsforexportrepositoryService',
            'proxyapiclient' => 'getProxyapiclientService',
            'reversio.module' => 'getReversio_ModuleService',
            'reversio_decoder' => 'getReversioDecoderService',
            'reversioapiconnect' => 'getReversioapiconnectService',
            'reversiocache' => 'getReversiocacheService',
            'reversiomultiselect' => 'getReversiomultiselectService',
            'tabrepository' => 'getTabrepositoryService',
            'token' => 'getTokenService',
            'uninstaller' => 'getUninstallerService',
            'versions' => 'getVersionsService',
        );

        $this->aliases = array();
    }

    /**
     * {@inheritdoc}
     */
    public function compile()
    {
        throw new LogicException('You cannot compile a dumped frozen container.');
    }

    /**
     * {@inheritdoc}
     */
    public function isFrozen()
    {
        return true;
    }

    /**
     * Gets the public 'apiclient' shared service.
     *
     * @return \ReversIO\Services\APIConnect\ApiClient
     */
    protected function getApiclientService()
    {
        return $this->services['apiclient'] = new \ReversIO\Services\APIConnect\ApiClient($this->get('clientfactory'));
    }

    /**
     * Gets the public 'apiheadersbuilder' shared service.
     *
     * @return \ReversIO\Services\APIConnect\ApiHeadersBuilder
     */
    protected function getApiheadersbuilderService()
    {
        return $this->services['apiheadersbuilder'] = new \ReversIO\Services\APIConnect\ApiHeadersBuilder($this->get('token'));
    }

    /**
     * Gets the public 'arrayadapter' shared service.
     *
     * @return \ReversIO\Adapter\ArrayAdapter
     */
    protected function getArrayadapterService()
    {
        return $this->services['arrayadapter'] = new \ReversIO\Adapter\ArrayAdapter();
    }

    /**
     * Gets the public 'autentification' shared service.
     *
     * @return \ReversIO\Services\Autentification\APIAuthentication
     */
    protected function getAutentificationService()
    {
        return $this->services['autentification'] = new \ReversIO\Services\Autentification\APIAuthentication($this->get('token'));
    }

    /**
     * Gets the public 'brandrepository' shared service.
     *
     * @return \ReversIO\Repository\BrandRepository
     */
    protected function getBrandrepositoryService()
    {
        return $this->services['brandrepository'] = new \ReversIO\Repository\BrandRepository();
    }

    /**
     * Gets the public 'brandservice' shared service.
     *
     * @return \ReversIO\Services\Brand\BrandService
     */
    protected function getBrandserviceService()
    {
        return $this->services['brandservice'] = new \ReversIO\Services\Brand\BrandService($this->get('reversio.module'), $this->get('arrayadapter'));
    }

    /**
     * Gets the public 'categorymaprepository' shared service.
     *
     * @return \ReversIO\Repository\CategoryMapRepository
     */
    protected function getCategorymaprepositoryService()
    {
        return $this->services['categorymaprepository'] = new \ReversIO\Repository\CategoryMapRepository();
    }

    /**
     * Gets the public 'categorymapservice' shared service.
     *
     * @return \ReversIO\Services\CategoryMapService
     */
    protected function getCategorymapserviceService()
    {
        return $this->services['categorymapservice'] = new \ReversIO\Services\CategoryMapService($this->get('categorymaprepository'));
    }

    /**
     * Gets the public 'categoryrepository' shared service.
     *
     * @return \ReversIO\Repository\CategoryRepository
     */
    protected function getCategoryrepositoryService()
    {
        return $this->services['categoryrepository'] = new \ReversIO\Repository\CategoryRepository();
    }

    /**
     * Gets the public 'clientfactory' shared service.
     *
     * @return \ReversIO\Factory\ClientFactory
     */
    protected function getClientfactoryService()
    {
        return $this->services['clientfactory'] = new \ReversIO\Factory\ClientFactory($this->get('versions'));
    }

    /**
     * Gets the public 'colourgetter' shared service.
     *
     * @return \ReversIO\Services\Getters\ColourGetter
     */
    protected function getColourgetterService()
    {
        return $this->services['colourgetter'] = new \ReversIO\Services\Getters\ColourGetter();
    }

    /**
     * Gets the public 'databaseinstall' shared service.
     *
     * @return \ReversIO\Install\DatabaseInstall
     */
    protected function getDatabaseinstallService()
    {
        return $this->services['databaseinstall'] = new \ReversIO\Install\DatabaseInstall($this->get('colourgetter'), $this->get('namegetter'));
    }

    /**
     * Gets the public 'exportedproductsrepository' shared service.
     *
     * @return \ReversIO\Repository\ExportedProductsRepository
     */
    protected function getExportedproductsrepositoryService()
    {
        return $this->services['exportedproductsrepository'] = new \ReversIO\Repository\ExportedProductsRepository();
    }

    /**
     * Gets the public 'installer' shared service.
     *
     * @return \ReversIO\Install\Installer
     */
    protected function getInstallerService()
    {
        return $this->services['installer'] = new \ReversIO\Install\Installer($this->get('reversio.module'), $this->get('databaseinstall'), array('configuration' => array('REVERS_IO_API_PUBLIC_KEY' => '', 'REVERS_IO_API_SECRET_KEY' => '', 'REVERS_IO_TEST_MODE_SETTING' => 1, 'REVERS_IO_ORDER_STATUS' => '', 'REVERS_IO_ENABLE_LOGGING_SETTING' => 0, 'REVERS_IO_STORE_LOGS' => 0, 'REVERS_IO_PRODUCT_INIT_EXPORT' => 1, 'REVERS_IO_BRAND_INIT_EXPORT' => 1), 'hooks' => array(0 => 'actionAdminOrdersListingFieldsModifier', 1 => 'displayAdminOrder', 2 => 'displayOrderDetail', 3 => 'actionObjectProductUpdateAfter', 4 => 'actionObjectProductDeleteAfter', 5 => 'actionObjectProductAddAfter', 6 => 'actionAdminControllerSetMedia', 7 => 'actionFrontControllerSetMedia', 8 => 'actionOrderStatusUpdate', 9 => 'moduleRoutes')));
    }

    /**
     * Gets the public 'loggerservice' shared service.
     *
     * @return \ReversIO\Repository\Logs\Logger
     */
    protected function getLoggerserviceService()
    {
        return $this->services['loggerservice'] = new \ReversIO\Repository\Logs\Logger($this->get('orderrepository'), $this->get('productrepository'), $this->get('brandrepository'));
    }

    /**
     * Gets the public 'logservice' shared service.
     *
     * @return \ReversIO\Services\Log\LogService
     */
    protected function getLogserviceService()
    {
        return $this->services['logservice'] = new \ReversIO\Services\Log\LogService($this->get('loggerservice'));
    }

    /**
     * Gets the public 'logsrepository' shared service.
     *
     * @return \ReversIO\Repository\Logs\LogsRepository
     */
    protected function getLogsrepositoryService()
    {
        return $this->services['logsrepository'] = new \ReversIO\Repository\Logs\LogsRepository();
    }

    /**
     * Gets the public 'modelservice' shared service.
     *
     * @return \ReversIO\Services\Product\ModelService
     */
    protected function getModelserviceService()
    {
        return $this->services['modelservice'] = new \ReversIO\Services\Product\ModelService($this->get('reversio.module'), $this->get('orderrepository'), $this->get('productexportrepository'), $this->get('reversioapiconnect'), $this->get('reversiocache'), $this->get('exportedproductsrepository'));
    }

    /**
     * Gets the public 'namegetter' shared service.
     *
     * @return \ReversIO\Services\Getters\ReversIoSettingNameGetter
     */
    protected function getNamegetterService()
    {
        return $this->services['namegetter'] = new \ReversIO\Services\Getters\ReversIoSettingNameGetter();
    }

    /**
     * Gets the public 'orderimportservice' shared service.
     *
     * @return \ReversIO\Services\Orders\OrderImportService
     */
    protected function getOrderimportserviceService()
    {
        return $this->services['orderimportservice'] = new \ReversIO\Services\Orders\OrderImportService($this->get('ordersimport'), $this->get('reversioapiconnect'), $this->get('orderrepository'));
    }

    /**
     * Gets the public 'orderrepository' shared service.
     *
     * @return \ReversIO\Repository\OrderRepository
     */
    protected function getOrderrepositoryService()
    {
        return $this->services['orderrepository'] = new \ReversIO\Repository\OrderRepository($this->get('colourgetter'));
    }

    /**
     * Gets the public 'ordersadmin' shared service.
     *
     * @return \ReversIO\Services\Orders\OrderListBuilder
     */
    protected function getOrdersadminService()
    {
        return $this->services['ordersadmin'] = new \ReversIO\Services\Orders\OrderListBuilder($this->get('orderrepository'));
    }

    /**
     * Gets the public 'ordersimport' shared service.
     *
     * @return \ReversIO\Services\Orders\OrdersRequestBuilder
     */
    protected function getOrdersimportService()
    {
        return $this->services['ordersimport'] = new \ReversIO\Services\Orders\OrdersRequestBuilder($this->get('orderrepository'), $this->get('reversio.module'), $this->get('modelservice'), $this->get('loggerservice'));
    }

    /**
     * Gets the public 'orderslistingrepository' shared service.
     *
     * @return \ReversIO\Repository\OrdersListingRepository
     */
    protected function getOrderslistingrepositoryService()
    {
        return $this->services['orderslistingrepository'] = new \ReversIO\Repository\OrdersListingRepository();
    }

    /**
     * Gets the public 'ordersretrieveservice' shared service.
     *
     * @return \ReversIO\Services\Orders\OrdersRetrieveService
     */
    protected function getOrdersretrieveserviceService()
    {
        return $this->services['ordersretrieveservice'] = new \ReversIO\Services\Orders\OrdersRetrieveService($this->get('reversio.module'));
    }

    /**
     * Gets the public 'orderstatuses' shared service.
     *
     * @return \ReversIO\Services\Orders\OrderStatus
     */
    protected function getOrderstatusesService()
    {
        return $this->services['orderstatuses'] = new \ReversIO\Services\Orders\OrderStatus();
    }

    /**
     * Gets the public 'productexportrepository' shared service.
     *
     * @return \ReversIO\Repository\ProductsForExportRepository
     */
    protected function getProductexportrepositoryService()
    {
        return $this->services['productexportrepository'] = new \ReversIO\Repository\ProductsForExportRepository();
    }

    /**
     * Gets the public 'productforexportservice' shared service.
     *
     * @return \ReversIO\Services\Product\ProductsForExportService
     */
    protected function getProductforexportserviceService()
    {
        return $this->services['productforexportservice'] = new \ReversIO\Services\Product\ProductsForExportService($this->get('productsforexportrepository'), $this->get('exportedproductsrepository'), $this->get('versions'));
    }

    /**
     * Gets the public 'productimporter' shared service.
     *
     * @return \ReversIO\Services\Product\ProductService
     */
    protected function getProductimporterService()
    {
        return $this->services['productimporter'] = new \ReversIO\Services\Product\ProductService($this->get('categorymapservice'));
    }

    /**
     * Gets the public 'productrepository' shared service.
     *
     * @return \ReversIO\Repository\ProductRepository
     */
    protected function getProductrepositoryService()
    {
        return $this->services['productrepository'] = new \ReversIO\Repository\ProductRepository();
    }

    /**
     * Gets the public 'productsforexportrepository' shared service.
     *
     * @return \ReversIO\Repository\ProductsForExportRepository
     */
    protected function getProductsforexportrepositoryService()
    {
        return $this->services['productsforexportrepository'] = new \ReversIO\Repository\ProductsForExportRepository();
    }

    /**
     * Gets the public 'proxyapiclient' shared service.
     *
     * @return \ReversIO\Proxy\ProxyApiClient
     */
    protected function getProxyapiclientService()
    {
        return $this->services['proxyapiclient'] = new \ReversIO\Proxy\ProxyApiClient($this->get('token'), $this->get('apiclient'), $this->get('reversio_decoder'));
    }

    /**
     * Gets the public 'reversio.module' shared service.
     *
     * @return \ReversIO
     */
    protected function getReversio_ModuleService()
    {
        return $this->services['reversio.module'] = \Module::getInstanceByName('reversio');
    }

    /**
     * Gets the public 'reversio_decoder' shared service.
     *
     * @return \ReversIO\Services\Decoder\Decoder
     */
    protected function getReversioDecoderService()
    {
        return $this->services['reversio_decoder'] = new \ReversIO\Services\Decoder\Decoder();
    }

    /**
     * Gets the public 'reversioapiconnect' shared service.
     *
     * @return \ReversIO\Services\APIConnect\ReversIOApi
     */
    protected function getReversioapiconnectService()
    {
        return $this->services['reversioapiconnect'] = new \ReversIO\Services\APIConnect\ReversIOApi($this->get('productimporter'), $this->get('orderrepository'), $this->get('logsrepository'), $this->get('ordersretrieveservice'), $this->get('loggerservice'), $this->get('token'), $this->get('proxyapiclient'), $this->get('productexportrepository'), $this->get('categorymaprepository'), $this->get('categoryrepository'), $this->get('brandservice'), $this->get('exportedproductsrepository'), $this->get('versions'), $this->get('productrepository'), $this->get('apiheadersbuilder'), $this->get('reversiocache'));
    }

    /**
     * Gets the public 'reversiocache' shared service.
     *
     * @return \ReversIO\Services\Cache\Cache
     */
    protected function getReversiocacheService()
    {
        return $this->services['reversiocache'] = new \ReversIO\Services\Cache\Cache($this->get('reversio.module'));
    }

    /**
     * Gets the public 'reversiomultiselect' shared service.
     *
     * @return \ReversIO\MultiSelect\MultiSelect
     */
    protected function getReversiomultiselectService()
    {
        return $this->services['reversiomultiselect'] = new \ReversIO\MultiSelect\MultiSelect();
    }

    /**
     * Gets the public 'tabrepository' shared service.
     *
     * @return \ReversIO\Repository\TabRepository
     */
    protected function getTabrepositoryService()
    {
        return $this->services['tabrepository'] = new \ReversIO\Repository\TabRepository();
    }

    /**
     * Gets the public 'token' shared service.
     *
     * @return \ReversIO\Services\APIConnect\Token
     */
    protected function getTokenService()
    {
        return $this->services['token'] = new \ReversIO\Services\APIConnect\Token($this->get('reversio_decoder'));
    }

    /**
     * Gets the public 'uninstaller' shared service.
     *
     * @return \ReversIO\Uninstall\Uninstaller
     */
    protected function getUninstallerService()
    {
        return $this->services['uninstaller'] = new \ReversIO\Uninstall\Uninstaller($this->get('reversio.module'), $this->get('databaseinstall'), $this->get('versions'));
    }

    /**
     * Gets the public 'versions' shared service.
     *
     * @return \ReversIO\Services\Versions\Versions
     */
    protected function getVersionsService()
    {
        return $this->services['versions'] = new \ReversIO\Services\Versions\Versions();
    }

    /**
     * {@inheritdoc}
     */
    public function getParameter($name)
    {
        $name = strtolower($name);

        if (!(isset($this->parameters[$name]) || array_key_exists($name, $this->parameters))) {
            throw new InvalidArgumentException(sprintf('The parameter "%s" must be defined.', $name));
        }

        return $this->parameters[$name];
    }

    /**
     * {@inheritdoc}
     */
    public function hasParameter($name)
    {
        $name = strtolower($name);

        return isset($this->parameters[$name]) || array_key_exists($name, $this->parameters);
    }

    /**
     * {@inheritdoc}
     */
    public function setParameter($name, $value)
    {
        throw new LogicException('Impossible to call set() on a frozen ParameterBag.');
    }

    /**
     * {@inheritdoc}
     */
    public function getParameterBag()
    {
        if (null === $this->parameterBag) {
            $this->parameterBag = new FrozenParameterBag($this->parameters);
        }

        return $this->parameterBag;
    }

    /**
     * Gets the default parameters.
     *
     * @return array An array of the default parameters
     */
    protected function getDefaultParameters()
    {
        return array(
            'module_settings' => array(
                'configuration' => array(
                    'REVERS_IO_API_PUBLIC_KEY' => '',
                    'REVERS_IO_API_SECRET_KEY' => '',
                    'REVERS_IO_TEST_MODE_SETTING' => 1,
                    'REVERS_IO_ORDER_STATUS' => '',
                    'REVERS_IO_ENABLE_LOGGING_SETTING' => 0,
                    'REVERS_IO_STORE_LOGS' => 0,
                    'REVERS_IO_PRODUCT_INIT_EXPORT' => 1,
                    'REVERS_IO_BRAND_INIT_EXPORT' => 1,
                ),
                'hooks' => array(
                    0 => 'actionAdminOrdersListingFieldsModifier',
                    1 => 'displayAdminOrder',
                    2 => 'displayOrderDetail',
                    3 => 'actionObjectProductUpdateAfter',
                    4 => 'actionObjectProductDeleteAfter',
                    5 => 'actionObjectProductAddAfter',
                    6 => 'actionAdminControllerSetMedia',
                    7 => 'actionFrontControllerSetMedia',
                    8 => 'actionOrderStatusUpdate',
                    9 => 'moduleRoutes',
                ),
            ),
        );
    }
}
