<?php

use Symfony\Component\DependencyInjection\Argument\RewindableGenerator;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Exception\RuntimeException;
use Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;

/**
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 *
 * @final since Symfony 3.3
 */
class ReversIOContainer extends Container
{
    private $parameters;
    private $targetDirs = [];

    public function __construct()
    {
        $this->parameters = $this->getDefaultParameters();

        $this->services = [];
        $this->normalizedIds = [
            'apiclient' => 'apiClient',
            'apiheadersbuilder' => 'apiHeadersBuilder',
            'arrayadapter' => 'arrayAdapter',
            'brandrepository' => 'brandRepository',
            'brandservice' => 'brandService',
            'categorymaprepository' => 'categoryMapRepository',
            'categorymapservice' => 'categoryMapService',
            'categoryrepository' => 'categoryRepository',
            'clientfactory' => 'clientFactory',
            'colourgetter' => 'colourGetter',
            'databaseinstall' => 'databaseInstall',
            'exportedproductsrepository' => 'exportedProductsRepository',
            'loggerservice' => 'loggerService',
            'logservice' => 'logService',
            'logsrepository' => 'logsRepository',
            'modelservice' => 'modelService',
            'namegetter' => 'nameGetter',
            'orderimportservice' => 'orderImportService',
            'orderrepository' => 'orderRepository',
            'ordersadmin' => 'ordersAdmin',
            'ordersimport' => 'ordersImport',
            'orderslistingrepository' => 'ordersListingRepository',
            'ordersretrieveservice' => 'ordersRetrieveService',
            'orderstatuses' => 'orderStatuses',
            'productexportrepository' => 'productExportRepository',
            'productforexportservice' => 'productForExportService',
            'productimporter' => 'productImporter',
            'productrepository' => 'productRepository',
            'productsforexportrepository' => 'productsForExportRepository',
            'proxyapiclient' => 'proxyApiClient',
            'reversioapiconnect' => 'reversIoApiConnect',
            'reversiocache' => 'reversIoCache',
            'reversiomultiselect' => 'reversioMultiSelect',
            'tabrepository' => 'tabRepository',
        ];
        $this->methodMap = [
            'apiClient' => 'getApiClientService',
            'apiHeadersBuilder' => 'getApiHeadersBuilderService',
            'arrayAdapter' => 'getArrayAdapterService',
            'autentification' => 'getAutentificationService',
            'brandRepository' => 'getBrandRepositoryService',
            'brandService' => 'getBrandServiceService',
            'categoryMapRepository' => 'getCategoryMapRepositoryService',
            'categoryMapService' => 'getCategoryMapServiceService',
            'categoryRepository' => 'getCategoryRepositoryService',
            'clientFactory' => 'getClientFactoryService',
            'colourGetter' => 'getColourGetterService',
            'databaseInstall' => 'getDatabaseInstallService',
            'exportedProductsRepository' => 'getExportedProductsRepositoryService',
            'installer' => 'getInstallerService',
            'logService' => 'getLogServiceService',
            'loggerService' => 'getLoggerServiceService',
            'logsRepository' => 'getLogsRepositoryService',
            'modelService' => 'getModelServiceService',
            'nameGetter' => 'getNameGetterService',
            'orderImportService' => 'getOrderImportServiceService',
            'orderRepository' => 'getOrderRepositoryService',
            'orderStatuses' => 'getOrderStatusesService',
            'ordersAdmin' => 'getOrdersAdminService',
            'ordersImport' => 'getOrdersImportService',
            'ordersListingRepository' => 'getOrdersListingRepositoryService',
            'ordersRetrieveService' => 'getOrdersRetrieveServiceService',
            'productExportRepository' => 'getProductExportRepositoryService',
            'productForExportService' => 'getProductForExportServiceService',
            'productImporter' => 'getProductImporterService',
            'productRepository' => 'getProductRepositoryService',
            'productsForExportRepository' => 'getProductsForExportRepositoryService',
            'proxyApiClient' => 'getProxyApiClientService',
            'reversIoApiConnect' => 'getReversIoApiConnectService',
            'reversIoCache' => 'getReversIoCacheService',
            'reversio.module' => 'getReversio_ModuleService',
            'reversioMultiSelect' => 'getReversioMultiSelectService',
            'reversio_decoder' => 'getReversioDecoderService',
            'tabRepository' => 'getTabRepositoryService',
            'token' => 'getTokenService',
            'uninstaller' => 'getUninstallerService',
            'versions' => 'getVersionsService',
        ];
        $this->privates = [
            'apiClient' => true,
            'apiHeadersBuilder' => true,
            'arrayAdapter' => true,
            'autentification' => true,
            'brandRepository' => true,
            'brandService' => true,
            'categoryMapRepository' => true,
            'categoryMapService' => true,
            'categoryRepository' => true,
            'clientFactory' => true,
            'colourGetter' => true,
            'databaseInstall' => true,
            'exportedProductsRepository' => true,
            'installer' => true,
            'logService' => true,
            'loggerService' => true,
            'logsRepository' => true,
            'modelService' => true,
            'nameGetter' => true,
            'orderImportService' => true,
            'orderRepository' => true,
            'orderStatuses' => true,
            'ordersAdmin' => true,
            'ordersImport' => true,
            'ordersListingRepository' => true,
            'ordersRetrieveService' => true,
            'productExportRepository' => true,
            'productForExportService' => true,
            'productImporter' => true,
            'productRepository' => true,
            'productsForExportRepository' => true,
            'proxyApiClient' => true,
            'reversIoApiConnect' => true,
            'reversIoCache' => true,
            'reversio.module' => true,
            'reversioMultiSelect' => true,
            'reversio_decoder' => true,
            'tabRepository' => true,
            'token' => true,
            'uninstaller' => true,
            'versions' => true,
        ];

        $this->aliases = [];
    }

    public function getRemovedIds()
    {
        return [
            'Psr\\Container\\ContainerInterface' => true,
            'Symfony\\Component\\DependencyInjection\\ContainerInterface' => true,
            'apiClient' => true,
            'apiHeadersBuilder' => true,
            'arrayAdapter' => true,
            'autentification' => true,
            'brandRepository' => true,
            'brandService' => true,
            'categoryMapRepository' => true,
            'categoryMapService' => true,
            'categoryRepository' => true,
            'clientFactory' => true,
            'colourGetter' => true,
            'databaseInstall' => true,
            'exportedProductsRepository' => true,
            'installer' => true,
            'logService' => true,
            'loggerService' => true,
            'logsRepository' => true,
            'modelService' => true,
            'nameGetter' => true,
            'orderImportService' => true,
            'orderRepository' => true,
            'orderStatuses' => true,
            'ordersAdmin' => true,
            'ordersImport' => true,
            'ordersListingRepository' => true,
            'ordersRetrieveService' => true,
            'productExportRepository' => true,
            'productForExportService' => true,
            'productImporter' => true,
            'productRepository' => true,
            'productsForExportRepository' => true,
            'proxyApiClient' => true,
            'reversIoApiConnect' => true,
            'reversIoCache' => true,
            'reversio.module' => true,
            'reversioMultiSelect' => true,
            'reversio_decoder' => true,
            'tabRepository' => true,
            'token' => true,
            'uninstaller' => true,
            'versions' => true,
        ];
    }

    public function compile()
    {
        throw new LogicException('You cannot compile a dumped container that was already compiled.');
    }

    public function isCompiled()
    {
        return true;
    }

    public function isFrozen()
    {
        @trigger_error(sprintf('The %s() method is deprecated since Symfony 3.3 and will be removed in 4.0. Use the isCompiled() method instead.', __METHOD__), E_USER_DEPRECATED);

        return true;
    }

    /**
     * Gets the private 'apiClient' shared service.
     *
     * @return \ReversIO\Services\APIConnect\ApiClient
     */
    protected function getApiClientService()
    {
        return $this->services['apiClient'] = new \ReversIO\Services\APIConnect\ApiClient(${($_ = isset($this->services['clientFactory']) ? $this->services['clientFactory'] : $this->getClientFactoryService()) && false ?: '_'});
    }

    /**
     * Gets the private 'apiHeadersBuilder' shared service.
     *
     * @return \ReversIO\Services\APIConnect\ApiHeadersBuilder
     */
    protected function getApiHeadersBuilderService()
    {
        return $this->services['apiHeadersBuilder'] = new \ReversIO\Services\APIConnect\ApiHeadersBuilder(${($_ = isset($this->services['token']) ? $this->services['token'] : $this->getTokenService()) && false ?: '_'});
    }

    /**
     * Gets the private 'arrayAdapter' shared service.
     *
     * @return \ReversIO\Adapter\ArrayAdapter
     */
    protected function getArrayAdapterService()
    {
        return $this->services['arrayAdapter'] = new \ReversIO\Adapter\ArrayAdapter();
    }

    /**
     * Gets the private 'autentification' shared service.
     *
     * @return \ReversIO\Services\Autentification\APIAuthentication
     */
    protected function getAutentificationService()
    {
        return $this->services['autentification'] = new \ReversIO\Services\Autentification\APIAuthentication(${($_ = isset($this->services['token']) ? $this->services['token'] : $this->getTokenService()) && false ?: '_'});
    }

    /**
     * Gets the private 'brandRepository' shared service.
     *
     * @return \ReversIO\Repository\BrandRepository
     */
    protected function getBrandRepositoryService()
    {
        return $this->services['brandRepository'] = new \ReversIO\Repository\BrandRepository();
    }

    /**
     * Gets the private 'brandService' shared service.
     *
     * @return \ReversIO\Services\Brand\BrandService
     */
    protected function getBrandServiceService()
    {
        return $this->services['brandService'] = new \ReversIO\Services\Brand\BrandService(${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'}, ${($_ = isset($this->services['arrayAdapter']) ? $this->services['arrayAdapter'] : ($this->services['arrayAdapter'] = new \ReversIO\Adapter\ArrayAdapter())) && false ?: '_'});
    }

    /**
     * Gets the private 'categoryMapRepository' shared service.
     *
     * @return \ReversIO\Repository\CategoryMapRepository
     */
    protected function getCategoryMapRepositoryService()
    {
        return $this->services['categoryMapRepository'] = new \ReversIO\Repository\CategoryMapRepository();
    }

    /**
     * Gets the private 'categoryMapService' shared service.
     *
     * @return \ReversIO\Services\CategoryMapService
     */
    protected function getCategoryMapServiceService()
    {
        return $this->services['categoryMapService'] = new \ReversIO\Services\CategoryMapService(${($_ = isset($this->services['categoryMapRepository']) ? $this->services['categoryMapRepository'] : ($this->services['categoryMapRepository'] = new \ReversIO\Repository\CategoryMapRepository())) && false ?: '_'});
    }

    /**
     * Gets the private 'categoryRepository' shared service.
     *
     * @return \ReversIO\Repository\CategoryRepository
     */
    protected function getCategoryRepositoryService()
    {
        return $this->services['categoryRepository'] = new \ReversIO\Repository\CategoryRepository();
    }

    /**
     * Gets the private 'clientFactory' shared service.
     *
     * @return \ReversIO\Factory\ClientFactory
     */
    protected function getClientFactoryService()
    {
        return $this->services['clientFactory'] = new \ReversIO\Factory\ClientFactory(${($_ = isset($this->services['versions']) ? $this->services['versions'] : ($this->services['versions'] = new \ReversIO\Services\Versions\Versions())) && false ?: '_'});
    }

    /**
     * Gets the private 'colourGetter' shared service.
     *
     * @return \ReversIO\Services\Getters\ColourGetter
     */
    protected function getColourGetterService()
    {
        return $this->services['colourGetter'] = new \ReversIO\Services\Getters\ColourGetter();
    }

    /**
     * Gets the private 'databaseInstall' shared service.
     *
     * @return \ReversIO\Install\DatabaseInstall
     */
    protected function getDatabaseInstallService()
    {
        return $this->services['databaseInstall'] = new \ReversIO\Install\DatabaseInstall(${($_ = isset($this->services['colourGetter']) ? $this->services['colourGetter'] : ($this->services['colourGetter'] = new \ReversIO\Services\Getters\ColourGetter())) && false ?: '_'}, ${($_ = isset($this->services['nameGetter']) ? $this->services['nameGetter'] : ($this->services['nameGetter'] = new \ReversIO\Services\Getters\ReversIoSettingNameGetter())) && false ?: '_'});
    }

    /**
     * Gets the private 'exportedProductsRepository' shared service.
     *
     * @return \ReversIO\Repository\ExportedProductsRepository
     */
    protected function getExportedProductsRepositoryService()
    {
        return $this->services['exportedProductsRepository'] = new \ReversIO\Repository\ExportedProductsRepository();
    }

    /**
     * Gets the private 'installer' shared service.
     *
     * @return \ReversIO\Install\Installer
     */
    protected function getInstallerService()
    {
        return $this->services['installer'] = new \ReversIO\Install\Installer(${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'}, ${($_ = isset($this->services['databaseInstall']) ? $this->services['databaseInstall'] : $this->getDatabaseInstallService()) && false ?: '_'}, ${($_ = isset($this->services['ordersAdmin']) ? $this->services['ordersAdmin'] : $this->getOrdersAdminService()) && false ?: '_'}, ${($_ = isset($this->services['versions']) ? $this->services['versions'] : ($this->services['versions'] = new \ReversIO\Services\Versions\Versions())) && false ?: '_'}, $this->parameters['module_settings']);
    }

    /**
     * Gets the private 'logService' shared service.
     *
     * @return \ReversIO\Services\Log\LogService
     */
    protected function getLogServiceService()
    {
        return $this->services['logService'] = new \ReversIO\Services\Log\LogService(${($_ = isset($this->services['loggerService']) ? $this->services['loggerService'] : $this->getLoggerServiceService()) && false ?: '_'});
    }

    /**
     * Gets the private 'loggerService' shared service.
     *
     * @return \ReversIO\Repository\Logs\Logger
     */
    protected function getLoggerServiceService()
    {
        return $this->services['loggerService'] = new \ReversIO\Repository\Logs\Logger(${($_ = isset($this->services['orderRepository']) ? $this->services['orderRepository'] : $this->getOrderRepositoryService()) && false ?: '_'}, ${($_ = isset($this->services['productRepository']) ? $this->services['productRepository'] : ($this->services['productRepository'] = new \ReversIO\Repository\ProductRepository())) && false ?: '_'}, ${($_ = isset($this->services['brandRepository']) ? $this->services['brandRepository'] : ($this->services['brandRepository'] = new \ReversIO\Repository\BrandRepository())) && false ?: '_'});
    }

    /**
     * Gets the private 'logsRepository' shared service.
     *
     * @return \ReversIO\Repository\Logs\LogsRepository
     */
    protected function getLogsRepositoryService()
    {
        return $this->services['logsRepository'] = new \ReversIO\Repository\Logs\LogsRepository();
    }

    /**
     * Gets the private 'modelService' shared service.
     *
     * @return \ReversIO\Services\Product\ModelService
     */
    protected function getModelServiceService()
    {
        return $this->services['modelService'] = new \ReversIO\Services\Product\ModelService(${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'}, ${($_ = isset($this->services['orderRepository']) ? $this->services['orderRepository'] : $this->getOrderRepositoryService()) && false ?: '_'}, ${($_ = isset($this->services['productExportRepository']) ? $this->services['productExportRepository'] : ($this->services['productExportRepository'] = new \ReversIO\Repository\ProductsForExportRepository())) && false ?: '_'}, ${($_ = isset($this->services['reversIoApiConnect']) ? $this->services['reversIoApiConnect'] : $this->getReversIoApiConnectService()) && false ?: '_'}, ${($_ = isset($this->services['reversIoCache']) ? $this->services['reversIoCache'] : $this->getReversIoCacheService()) && false ?: '_'}, ${($_ = isset($this->services['exportedProductsRepository']) ? $this->services['exportedProductsRepository'] : ($this->services['exportedProductsRepository'] = new \ReversIO\Repository\ExportedProductsRepository())) && false ?: '_'});
    }

    /**
     * Gets the private 'nameGetter' shared service.
     *
     * @return \ReversIO\Services\Getters\ReversIoSettingNameGetter
     */
    protected function getNameGetterService()
    {
        return $this->services['nameGetter'] = new \ReversIO\Services\Getters\ReversIoSettingNameGetter();
    }

    /**
     * Gets the private 'orderImportService' shared service.
     *
     * @return \ReversIO\Services\Orders\OrderImportService
     */
    protected function getOrderImportServiceService()
    {
        return $this->services['orderImportService'] = new \ReversIO\Services\Orders\OrderImportService(${($_ = isset($this->services['ordersImport']) ? $this->services['ordersImport'] : $this->getOrdersImportService()) && false ?: '_'}, ${($_ = isset($this->services['reversIoApiConnect']) ? $this->services['reversIoApiConnect'] : $this->getReversIoApiConnectService()) && false ?: '_'}, ${($_ = isset($this->services['orderRepository']) ? $this->services['orderRepository'] : $this->getOrderRepositoryService()) && false ?: '_'});
    }

    /**
     * Gets the private 'orderRepository' shared service.
     *
     * @return \ReversIO\Repository\OrderRepository
     */
    protected function getOrderRepositoryService()
    {
        return $this->services['orderRepository'] = new \ReversIO\Repository\OrderRepository(${($_ = isset($this->services['colourGetter']) ? $this->services['colourGetter'] : ($this->services['colourGetter'] = new \ReversIO\Services\Getters\ColourGetter())) && false ?: '_'});
    }

    /**
     * Gets the private 'orderStatuses' shared service.
     *
     * @return \ReversIO\Services\Orders\OrderStatus
     */
    protected function getOrderStatusesService()
    {
        return $this->services['orderStatuses'] = new \ReversIO\Services\Orders\OrderStatus();
    }

    /**
     * Gets the private 'ordersAdmin' shared service.
     *
     * @return \ReversIO\Services\Orders\OrderListBuilder
     */
    protected function getOrdersAdminService()
    {
        return $this->services['ordersAdmin'] = new \ReversIO\Services\Orders\OrderListBuilder(${($_ = isset($this->services['orderRepository']) ? $this->services['orderRepository'] : $this->getOrderRepositoryService()) && false ?: '_'});
    }

    /**
     * Gets the private 'ordersImport' shared service.
     *
     * @return \ReversIO\Services\Orders\OrdersRequestBuilder
     */
    protected function getOrdersImportService()
    {
        return $this->services['ordersImport'] = new \ReversIO\Services\Orders\OrdersRequestBuilder(${($_ = isset($this->services['orderRepository']) ? $this->services['orderRepository'] : $this->getOrderRepositoryService()) && false ?: '_'}, ${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'}, ${($_ = isset($this->services['modelService']) ? $this->services['modelService'] : $this->getModelServiceService()) && false ?: '_'}, ${($_ = isset($this->services['loggerService']) ? $this->services['loggerService'] : $this->getLoggerServiceService()) && false ?: '_'});
    }

    /**
     * Gets the private 'ordersListingRepository' shared service.
     *
     * @return \ReversIO\Repository\OrdersListingRepository
     */
    protected function getOrdersListingRepositoryService()
    {
        return $this->services['ordersListingRepository'] = new \ReversIO\Repository\OrdersListingRepository();
    }

    /**
     * Gets the private 'ordersRetrieveService' shared service.
     *
     * @return \ReversIO\Services\Orders\OrdersRetrieveService
     */
    protected function getOrdersRetrieveServiceService()
    {
        return $this->services['ordersRetrieveService'] = new \ReversIO\Services\Orders\OrdersRetrieveService(${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'});
    }

    /**
     * Gets the private 'productExportRepository' shared service.
     *
     * @return \ReversIO\Repository\ProductsForExportRepository
     */
    protected function getProductExportRepositoryService()
    {
        return $this->services['productExportRepository'] = new \ReversIO\Repository\ProductsForExportRepository();
    }

    /**
     * Gets the private 'productForExportService' shared service.
     *
     * @return \ReversIO\Services\Product\ProductsForExportService
     */
    protected function getProductForExportServiceService()
    {
        return $this->services['productForExportService'] = new \ReversIO\Services\Product\ProductsForExportService(${($_ = isset($this->services['productsForExportRepository']) ? $this->services['productsForExportRepository'] : ($this->services['productsForExportRepository'] = new \ReversIO\Repository\ProductsForExportRepository())) && false ?: '_'}, ${($_ = isset($this->services['exportedProductsRepository']) ? $this->services['exportedProductsRepository'] : ($this->services['exportedProductsRepository'] = new \ReversIO\Repository\ExportedProductsRepository())) && false ?: '_'}, ${($_ = isset($this->services['versions']) ? $this->services['versions'] : ($this->services['versions'] = new \ReversIO\Services\Versions\Versions())) && false ?: '_'});
    }

    /**
     * Gets the private 'productImporter' shared service.
     *
     * @return \ReversIO\Services\Product\ProductService
     */
    protected function getProductImporterService()
    {
        return $this->services['productImporter'] = new \ReversIO\Services\Product\ProductService(${($_ = isset($this->services['categoryMapService']) ? $this->services['categoryMapService'] : $this->getCategoryMapServiceService()) && false ?: '_'});
    }

    /**
     * Gets the private 'productRepository' shared service.
     *
     * @return \ReversIO\Repository\ProductRepository
     */
    protected function getProductRepositoryService()
    {
        return $this->services['productRepository'] = new \ReversIO\Repository\ProductRepository();
    }

    /**
     * Gets the private 'productsForExportRepository' shared service.
     *
     * @return \ReversIO\Repository\ProductsForExportRepository
     */
    protected function getProductsForExportRepositoryService()
    {
        return $this->services['productsForExportRepository'] = new \ReversIO\Repository\ProductsForExportRepository();
    }

    /**
     * Gets the private 'proxyApiClient' shared service.
     *
     * @return \ReversIO\Proxy\ProxyApiClient
     */
    protected function getProxyApiClientService()
    {
        return $this->services['proxyApiClient'] = new \ReversIO\Proxy\ProxyApiClient(${($_ = isset($this->services['token']) ? $this->services['token'] : $this->getTokenService()) && false ?: '_'}, ${($_ = isset($this->services['apiClient']) ? $this->services['apiClient'] : $this->getApiClientService()) && false ?: '_'}, ${($_ = isset($this->services['reversio_decoder']) ? $this->services['reversio_decoder'] : ($this->services['reversio_decoder'] = new \ReversIO\Services\Decoder\Decoder())) && false ?: '_'});
    }

    /**
     * Gets the private 'reversIoApiConnect' shared service.
     *
     * @return \ReversIO\Services\APIConnect\ReversIOApi
     */
    protected function getReversIoApiConnectService()
    {
        return $this->services['reversIoApiConnect'] = new \ReversIO\Services\APIConnect\ReversIOApi(${($_ = isset($this->services['productImporter']) ? $this->services['productImporter'] : $this->getProductImporterService()) && false ?: '_'}, ${($_ = isset($this->services['orderRepository']) ? $this->services['orderRepository'] : $this->getOrderRepositoryService()) && false ?: '_'}, ${($_ = isset($this->services['logsRepository']) ? $this->services['logsRepository'] : ($this->services['logsRepository'] = new \ReversIO\Repository\Logs\LogsRepository())) && false ?: '_'}, ${($_ = isset($this->services['ordersRetrieveService']) ? $this->services['ordersRetrieveService'] : $this->getOrdersRetrieveServiceService()) && false ?: '_'}, ${($_ = isset($this->services['loggerService']) ? $this->services['loggerService'] : $this->getLoggerServiceService()) && false ?: '_'}, ${($_ = isset($this->services['token']) ? $this->services['token'] : $this->getTokenService()) && false ?: '_'}, ${($_ = isset($this->services['proxyApiClient']) ? $this->services['proxyApiClient'] : $this->getProxyApiClientService()) && false ?: '_'}, ${($_ = isset($this->services['productExportRepository']) ? $this->services['productExportRepository'] : ($this->services['productExportRepository'] = new \ReversIO\Repository\ProductsForExportRepository())) && false ?: '_'}, ${($_ = isset($this->services['categoryMapRepository']) ? $this->services['categoryMapRepository'] : ($this->services['categoryMapRepository'] = new \ReversIO\Repository\CategoryMapRepository())) && false ?: '_'}, ${($_ = isset($this->services['categoryRepository']) ? $this->services['categoryRepository'] : ($this->services['categoryRepository'] = new \ReversIO\Repository\CategoryRepository())) && false ?: '_'}, ${($_ = isset($this->services['brandService']) ? $this->services['brandService'] : $this->getBrandServiceService()) && false ?: '_'}, ${($_ = isset($this->services['exportedProductsRepository']) ? $this->services['exportedProductsRepository'] : ($this->services['exportedProductsRepository'] = new \ReversIO\Repository\ExportedProductsRepository())) && false ?: '_'}, ${($_ = isset($this->services['versions']) ? $this->services['versions'] : ($this->services['versions'] = new \ReversIO\Services\Versions\Versions())) && false ?: '_'}, ${($_ = isset($this->services['productRepository']) ? $this->services['productRepository'] : ($this->services['productRepository'] = new \ReversIO\Repository\ProductRepository())) && false ?: '_'}, ${($_ = isset($this->services['apiHeadersBuilder']) ? $this->services['apiHeadersBuilder'] : $this->getApiHeadersBuilderService()) && false ?: '_'}, ${($_ = isset($this->services['reversIoCache']) ? $this->services['reversIoCache'] : $this->getReversIoCacheService()) && false ?: '_'});
    }

    /**
     * Gets the private 'reversIoCache' shared service.
     *
     * @return \ReversIO\Services\Cache\Cache
     */
    protected function getReversIoCacheService()
    {
        return $this->services['reversIoCache'] = new \ReversIO\Services\Cache\Cache(${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'});
    }

    /**
     * Gets the private 'reversio.module' shared service.
     *
     * @return \ReversIO
     */
    protected function getReversio_ModuleService()
    {
        return $this->services['reversio.module'] = \Module::getInstanceByName('reversio');
    }

    /**
     * Gets the private 'reversioMultiSelect' shared service.
     *
     * @return \ReversIO\MultiSelect\MultiSelect
     */
    protected function getReversioMultiSelectService()
    {
        return $this->services['reversioMultiSelect'] = new \ReversIO\MultiSelect\MultiSelect();
    }

    /**
     * Gets the private 'reversio_decoder' shared service.
     *
     * @return \ReversIO\Services\Decoder\Decoder
     */
    protected function getReversioDecoderService()
    {
        return $this->services['reversio_decoder'] = new \ReversIO\Services\Decoder\Decoder();
    }

    /**
     * Gets the private 'tabRepository' shared service.
     *
     * @return \ReversIO\Repository\TabRepository
     */
    protected function getTabRepositoryService()
    {
        return $this->services['tabRepository'] = new \ReversIO\Repository\TabRepository();
    }

    /**
     * Gets the private 'token' shared service.
     *
     * @return \ReversIO\Services\APIConnect\Token
     */
    protected function getTokenService()
    {
        return $this->services['token'] = new \ReversIO\Services\APIConnect\Token(${($_ = isset($this->services['reversio_decoder']) ? $this->services['reversio_decoder'] : ($this->services['reversio_decoder'] = new \ReversIO\Services\Decoder\Decoder())) && false ?: '_'});
    }

    /**
     * Gets the private 'uninstaller' shared service.
     *
     * @return \ReversIO\Uninstall\Uninstaller
     */
    protected function getUninstallerService()
    {
        return $this->services['uninstaller'] = new \ReversIO\Uninstall\Uninstaller(${($_ = isset($this->services['reversio.module']) ? $this->services['reversio.module'] : $this->getReversio_ModuleService()) && false ?: '_'}, ${($_ = isset($this->services['databaseInstall']) ? $this->services['databaseInstall'] : $this->getDatabaseInstallService()) && false ?: '_'}, ${($_ = isset($this->services['versions']) ? $this->services['versions'] : ($this->services['versions'] = new \ReversIO\Services\Versions\Versions())) && false ?: '_'});
    }

    /**
     * Gets the private 'versions' shared service.
     *
     * @return \ReversIO\Services\Versions\Versions
     */
    protected function getVersionsService()
    {
        return $this->services['versions'] = new \ReversIO\Services\Versions\Versions();
    }

    public function getParameter($name)
    {
        $name = (string) $name;
        if (!(isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters))) {
            $name = $this->normalizeParameterName($name);

            if (!(isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters))) {
                throw new InvalidArgumentException(sprintf('The parameter "%s" must be defined.', $name));
            }
        }
        if (isset($this->loadedDynamicParameters[$name])) {
            return $this->loadedDynamicParameters[$name] ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
        }

        return $this->parameters[$name];
    }

    public function hasParameter($name)
    {
        $name = (string) $name;
        $name = $this->normalizeParameterName($name);

        return isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters);
    }

    public function setParameter($name, $value)
    {
        throw new LogicException('Impossible to call set() on a frozen ParameterBag.');
    }

    public function getParameterBag()
    {
        if (null === $this->parameterBag) {
            $parameters = $this->parameters;
            foreach ($this->loadedDynamicParameters as $name => $loaded) {
                $parameters[$name] = $loaded ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
            }
            $this->parameterBag = new FrozenParameterBag($parameters);
        }

        return $this->parameterBag;
    }

    private $loadedDynamicParameters = [];
    private $dynamicParameters = [];

    /**
     * Computes a dynamic parameter.
     *
     * @param string $name The name of the dynamic parameter to load
     *
     * @return mixed The value of the dynamic parameter
     *
     * @throws InvalidArgumentException When the dynamic parameter does not exist
     */
    private function getDynamicParameter($name)
    {
        throw new InvalidArgumentException(sprintf('The dynamic parameter "%s" must be defined.', $name));
    }

    private $normalizedParameterNames = [];

    private function normalizeParameterName($name)
    {
        if (isset($this->normalizedParameterNames[$normalizedName = strtolower($name)]) || isset($this->parameters[$normalizedName]) || array_key_exists($normalizedName, $this->parameters)) {
            $normalizedName = isset($this->normalizedParameterNames[$normalizedName]) ? $this->normalizedParameterNames[$normalizedName] : $normalizedName;
            if ((string) $name !== $normalizedName) {
                @trigger_error(sprintf('Parameter names will be made case sensitive in Symfony 4.0. Using "%s" instead of "%s" is deprecated since Symfony 3.4.', $name, $normalizedName), E_USER_DEPRECATED);
            }
        } else {
            $normalizedName = $this->normalizedParameterNames[$normalizedName] = (string) $name;
        }

        return $normalizedName;
    }

    /**
     * Gets the default parameters.
     *
     * @return array An array of the default parameters
     */
    protected function getDefaultParameters()
    {
        return [
            'module_settings' => [
                'configuration' => [
                    'REVERS_IO_API_PUBLIC_KEY' => '',
                    'REVERS_IO_API_SECRET_KEY' => '',
                    'REVERS_IO_TEST_MODE_SETTING' => 1,
                    'REVERS_IO_ORDER_STATUS' => '',
                    'REVERS_IO_ENABLE_LOGGING_SETTING' => 0,
                    'REVERS_IO_STORE_LOGS' => 0,
                    'REVERS_IO_PRODUCT_INIT_EXPORT' => 1,
                    'REVERS_IO_BRAND_INIT_EXPORT' => 1,
                ],
                'hooks' => [
                    0 => 'actionAdminOrdersListingFieldsModifier',
                    1 => 'displayAdminOrder',
                    2 => 'displayOrderDetail',
                    3 => 'actionObjectProductUpdateAfter',
                    4 => 'actionObjectProductDeleteAfter',
                    5 => 'actionObjectProductAddAfter',
                    6 => 'actionAdminControllerSetMedia',
                    7 => 'actionFrontControllerSetMedia',
                    8 => 'actionOrderStatusUpdate',
                    9 => 'moduleRoutes',
                ],
            ],
        ];
    }
}
